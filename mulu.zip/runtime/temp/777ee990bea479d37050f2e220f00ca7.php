<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:97:"G:\myblog\tool\phpStudy\PHPTutorial\WWW\blog\public/../application/admin\view\category\index.html";i:1537602225;s:86:"G:\myblog\tool\phpStudy\PHPTutorial\WWW\blog\application\admin\view\common\header.html";i:1536935087;s:84:"G:\myblog\tool\phpStudy\PHPTutorial\WWW\blog\application\admin\view\common\list.html";i:1537600888;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>栏目列表</title>
    <link rel="stylesheet" href="/static/admin/css/bootstrap.min.css">
    <link rel="stylesheet" href="/static/admin/tocss/main.css">
    <style>
        /*管理员列表表格样式开始*/

        .rightbody .mytable {
            width: 100%;
            border-collapse: collapse;
            font-size: 16px;
        }

        .mytable th,
        .mytable td {
            border: 1px solid #ddd;
            padding: 10px;
        }

        .mytable th {
            background-color: #eee;
        }

        .mytable tr:not(:first-child):hover {
            background-color: rgb(250, 250, 250);
        }

        .mytable .label {
            font-size: 15px;
            font-weight: normal;
            padding-top: 5px;
            margin: 2px;
            display: inline-block;
        }

        .mytable .label .glyphicon {
            margin-right: 5px;
        }

        /*管理员列表表格样式结束*/

        .fenye {
            width: 100%;
            text-align: center;
            margin: 20px 0;
        }
    </style>
</head>

<body>
    <!--页头开始-->
    <header class="navbar navbar-default">
    <div class="mycontainer">
        <a href="#" class="navbar-brand" id="mylogo">MANGYU</a>
        <h4>后台管理</h4>
        <section  class="logout">
            <a href="<?php echo url('manager/reset'); ?>"><span class="glyphicon glyphicon-user"></span>修改我的密码</a>
            <a href="#"><span class="glyphicon glyphicon-user"></span></a>
            <a href="<?php echo url('login/logout'); ?>"><span class="glyphicon glyphicon-log-out"></span>登出</a>
        </section>
    </div>
</header>
    <!--页头结束-->

    <!--页面内容开始-->
    <div class="mycontainer">
        <div class="clearfix">

            <!--菜单列表开始-->
            <!--菜单列表开始-->
<label id="toggle-label" class="visible-xs-inline-block" for="toggle-checkbox">
    <span class="glyphicon glyphicon-menu-hamburger"></span>
</label>
<input class="hidden" id="toggle-checkbox" type="checkbox">
<nav class="column leftul hidden-xs">
    <div>
        <div class="top-hidden"></div>
        <div class="search">
            <span class="glyphicon glyphicon-search"></span>
            <input type="text" class="form-control">
        </div>
        <ul id="ulNav">
            <li  class="active-liNav">
                <a href="#">
                    <span class="glyphicon glyphicon-user left-icon"></span>管理员
                    <span class="glyphicon glyphicon-menu-right right-icon"></span>
                </a>
                <ul class="two-ul">
                    <li class="active-two-li">
                        <a href="<?php echo url('manager/index'); ?>">管理员列表
                            <!--   <span class="glyphicon glyphicon-menu-right right-icon"></span> -->
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo url('manager/add'); ?>">添加管理员
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="#">
                    <span class="glyphicon glyphicon-list-alt left-icon"></span>栏目
                    <span class="glyphicon glyphicon-menu-right right-icon"></span>
                </a>
                <ul class="two-ul">
                    <li>
                        <a href="<?php echo url('category/index'); ?>">栏目列表
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo url('category/add'); ?>">添加栏目
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo url('category/edit'); ?>">栏目编辑
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="#">
                    <span class="glyphicon glyphicon-cog left-icon"></span>系统
                    <span class="glyphicon glyphicon-menu-right right-icon"></span>
                </a>
                <ul class="two-ul">
                    <li>
                        <a href="admininfo.html">系统信息
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="adminlogin.html">
                    <span class="glyphicon glyphicon-log-out left-icon"></span>登出
                    <span class="glyphicon glyphicon-menu-right right-icon"></span>
                </a>
            </li>
        </ul>
    </div>
</nav>
<!--菜单列表结束-->
            <!--菜单列表结束-->

            <!--右侧主内容开始-->
            <section class="top-title">
                <div class="col-md-12 column">
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">控制面板</a>
                        </li>
                        <li class="active">栏目列表</li>
                    </ol>
                </div>
            </section>
            <div class="rightbody">
                <table class="mytable">
                    <tr>
                        <th width="100px">栏目ID</th>
                        <th>栏目标题</th>
                        <th width="100">栏目标识</th>
                        <th width="200px">操作</th>
                    </tr>
                    <!--删除提示框-->
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×
                                    </button>
                                    <h4 class="modal-title" id="myModalLabel">
                                        提示信息
                                    </h4>
                                </div>
                                <div class="modal-body">
                                   确定删除吗？
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">关闭
                                    </button>
                                    <button type="button" class="btn btn-primary">
                                        确认
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if(is_array($cate) || $cate instanceof \think\Collection || $cate instanceof \think\Paginator): $i = 0; $__LIST__ = $cate;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <tr>
                        <td><?php echo $vo['id']; ?></td>
                        <td><?php echo $vo['title']; ?></td>
                        <td><?php echo $vo['mark']; ?></td>
                        <td>
                            <a href="columnEdit.html" class="label label-warning">
                                <span class="glyphicon  glyphicon-edit"></span>编辑</a>
                            <a data-toggle="modal" data-target="#myModal" class="label label-danger">
                                <span class="glyphicon glyphicon-trash"></span>删除</a>

                        </td>
                    </tr>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </table>
                <div class="fenye">
                    <nav aria-label="Page navigation">
                        <ul class="pagination  pagination-lg">
                            <?php echo $cate->render(); ?>
                        </ul>
                    </nav>
                </div>
            </div>
            <!--右侧主内容结束-->
        </div>
    </div>
    <!--页面内容结束-->
    <script src="/static/admin/js/jquery.min.js"></script>
    <script src="/static/admin/js/bootstrap.min.js"></script>
    <script>
        $(function () {
            $('#ulNav>li').click(function () {
                $(this).toggleClass('active-liNav');
            })
        })
    </script>
</body>

</html>