<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:96:"G:\myblog\tool\phpStudy\PHPTutorial\WWW\blog\public/../application/admin\view\category\edit.html";i:1537601004;s:84:"G:\myblog\tool\phpStudy\PHPTutorial\WWW\blog\application\admin\view\common\list.html";i:1537600888;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>栏目列表</title>
    <link rel="stylesheet" href="/static/admin/css/bootstrap.min.css">
    <link rel="stylesheet" href="/static/admin/tocss/main.css">
    <style>
        .myform-form {
            width: 100%;
            font-size: 16px;
        }

        .myform-form .myform-line {
            width: 100%;
            margin: 26px 0;
        }

        .myform-form .myform-left {
            width: 150px;
            text-align: right;
            font-weight: normal;
            margin-right: 10px;
        }

        .myform-form .myform-right {
            width: 250px;
            text-align: left;
            padding: 10px;
            border: 1px solid #ddd;
        }

        .myform-form .myform-btn {
            width: 100px;
            text-align: center;
            color: #fff;
            background-color: #22262e;
            border-radius: 5px;
            padding: 10px;
        }
        input[type=file]{
            display: inline-block;
        }
    </style>
</head>

<body>

    <!--页头开始-->
    <!--菜单列表开始-->
<label id="toggle-label" class="visible-xs-inline-block" for="toggle-checkbox">
    <span class="glyphicon glyphicon-menu-hamburger"></span>
</label>
<input class="hidden" id="toggle-checkbox" type="checkbox">
<nav class="column leftul hidden-xs">
    <div>
        <div class="top-hidden"></div>
        <div class="search">
            <span class="glyphicon glyphicon-search"></span>
            <input type="text" class="form-control">
        </div>
        <ul id="ulNav">
            <li  class="active-liNav">
                <a href="#">
                    <span class="glyphicon glyphicon-user left-icon"></span>管理员
                    <span class="glyphicon glyphicon-menu-right right-icon"></span>
                </a>
                <ul class="two-ul">
                    <li class="active-two-li">
                        <a href="<?php echo url('manager/index'); ?>">管理员列表
                            <!--   <span class="glyphicon glyphicon-menu-right right-icon"></span> -->
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo url('manager/add'); ?>">添加管理员
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="#">
                    <span class="glyphicon glyphicon-list-alt left-icon"></span>栏目
                    <span class="glyphicon glyphicon-menu-right right-icon"></span>
                </a>
                <ul class="two-ul">
                    <li>
                        <a href="<?php echo url('category/index'); ?>">栏目列表
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo url('category/add'); ?>">添加栏目
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo url('category/edit'); ?>">栏目编辑
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="#">
                    <span class="glyphicon glyphicon-cog left-icon"></span>系统
                    <span class="glyphicon glyphicon-menu-right right-icon"></span>
                </a>
                <ul class="two-ul">
                    <li>
                        <a href="admininfo.html">系统信息
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="adminlogin.html">
                    <span class="glyphicon glyphicon-log-out left-icon"></span>登出
                    <span class="glyphicon glyphicon-menu-right right-icon"></span>
                </a>
            </li>
        </ul>
    </div>
</nav>
<!--菜单列表结束-->
    <!--页头结束-->

    <div class="mycontainer">
        <div class="clearfix">

            <!--菜单列表开始-->
            <!--菜单列表开始-->
<label id="toggle-label" class="visible-xs-inline-block" for="toggle-checkbox">
    <span class="glyphicon glyphicon-menu-hamburger"></span>
</label>
<input class="hidden" id="toggle-checkbox" type="checkbox">
<nav class="column leftul hidden-xs">
    <div>
        <div class="top-hidden"></div>
        <div class="search">
            <span class="glyphicon glyphicon-search"></span>
            <input type="text" class="form-control">
        </div>
        <ul id="ulNav">
            <li  class="active-liNav">
                <a href="#">
                    <span class="glyphicon glyphicon-user left-icon"></span>管理员
                    <span class="glyphicon glyphicon-menu-right right-icon"></span>
                </a>
                <ul class="two-ul">
                    <li class="active-two-li">
                        <a href="<?php echo url('manager/index'); ?>">管理员列表
                            <!--   <span class="glyphicon glyphicon-menu-right right-icon"></span> -->
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo url('manager/add'); ?>">添加管理员
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="#">
                    <span class="glyphicon glyphicon-list-alt left-icon"></span>栏目
                    <span class="glyphicon glyphicon-menu-right right-icon"></span>
                </a>
                <ul class="two-ul">
                    <li>
                        <a href="<?php echo url('category/index'); ?>">栏目列表
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo url('category/add'); ?>">添加栏目
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo url('category/edit'); ?>">栏目编辑
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="#">
                    <span class="glyphicon glyphicon-cog left-icon"></span>系统
                    <span class="glyphicon glyphicon-menu-right right-icon"></span>
                </a>
                <ul class="two-ul">
                    <li>
                        <a href="admininfo.html">系统信息
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="adminlogin.html">
                    <span class="glyphicon glyphicon-log-out left-icon"></span>登出
                    <span class="glyphicon glyphicon-menu-right right-icon"></span>
                </a>
            </li>
        </ul>
    </div>
</nav>
<!--菜单列表结束-->
            <!--菜单列表结束-->

            <!--主内容开始-->
            <section class="top-title">
                <div class="col-md-12 column">
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">控制面板</a>
                        </li>
                        <li class="active">栏目编辑</li>
                    </ol>
                </div>
            </section>
            <div class="rightbody">
                <div class="myform-form">
                    <p class="myform-line">
                        <label class="myform-left">栏目标题：</label>
                        <input class="myform-right" type="text" placeholder="请输入栏目标题">
                    </p>
                    <p class="myform-line">
                        <label class="myform-left">栏目图片：</label>
                        <input type="file" class="myform-right">
                    </p>

                    <p class="myform-line">
                        <label class="myform-left">栏目关键字：</label>
                        <input class="myform-right" type="text" placeholder="请输入栏目关键字">
                    </p>
                    <p class="myform-line">
                        <label class="myform-left">摘要信息：</label>
                        <input class="myform-right" type="text" placeholder="请输入栏目摘要信息">
                    </p>

                    <p class="myform-line">
                        <label class="myform-left"> </label>
                        <!--左边占宽-->
                        <input class="myform-right myform-btn" type="submit" value="修改">
                    </p>
                </div>
            </div>
            <!--右侧主内容结束-->
        </div>
    </div>
    <script src="/static/admin/js/jquery.min.js"></script>
    <script src="/static/admin/js/bootstrap.min.js"></script>
    <script>
        $(function () {
            $('#ulNav>li').click(function () {
                $(this).toggleClass('active-liNav');
            })
        })
    </script>
</body>

</html>