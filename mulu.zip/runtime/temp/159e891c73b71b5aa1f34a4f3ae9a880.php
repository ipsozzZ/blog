<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:94:"G:\myblog\tool\phpStudy\PHPTutorial\WWW\blog\public/../application/admin\view\manager\add.html";i:1537596404;s:86:"G:\myblog\tool\phpStudy\PHPTutorial\WWW\blog\application\admin\view\common\header.html";i:1536935087;s:84:"G:\myblog\tool\phpStudy\PHPTutorial\WWW\blog\application\admin\view\common\list.html";i:1537600888;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>管理员列表</title>
    <link rel="stylesheet" href="/static/admin/css/bootstrap.min.css">
    <link rel="stylesheet" href="/static/admin/tocss/main.css">
    <style>
        .myform-form {
            width: 100%;
            font-size: 16px;
        }

        .myform-form .myform-line {
            width: 100%;
            margin: 26px 0;
        }

        .myform-form .myform-left {
            width: 150px;
            text-align: right;
            font-weight: normal;
            margin-right: 10px;
        }

        .myform-form .myform-right {
            width: 250px;
            text-align: left;
            padding: 10px;
            border: 1px solid #ddd;
        }

        .myform-form .myform-btn {
            width: 100px;
            text-align: center;
            color: #fff;
            background-color: #22262e;
            border-radius: 5px;
            padding: 10px;
        }
    </style>

</head>

<body>
<header class="navbar navbar-default">
    <div class="mycontainer">
        <a href="#" class="navbar-brand" id="mylogo">MANGYU</a>
        <h4>后台管理</h4>
        <section  class="logout">
            <a href="<?php echo url('manager/reset'); ?>"><span class="glyphicon glyphicon-user"></span>修改我的密码</a>
            <a href="#"><span class="glyphicon glyphicon-user"></span></a>
            <a href="<?php echo url('login/logout'); ?>"><span class="glyphicon glyphicon-log-out"></span>登出</a>
        </section>
    </div>
</header>
<div class="mycontainer">
    <div class="clearfix">
        <!--菜单列表开始-->
<label id="toggle-label" class="visible-xs-inline-block" for="toggle-checkbox">
    <span class="glyphicon glyphicon-menu-hamburger"></span>
</label>
<input class="hidden" id="toggle-checkbox" type="checkbox">
<nav class="column leftul hidden-xs">
    <div>
        <div class="top-hidden"></div>
        <div class="search">
            <span class="glyphicon glyphicon-search"></span>
            <input type="text" class="form-control">
        </div>
        <ul id="ulNav">
            <li  class="active-liNav">
                <a href="#">
                    <span class="glyphicon glyphicon-user left-icon"></span>管理员
                    <span class="glyphicon glyphicon-menu-right right-icon"></span>
                </a>
                <ul class="two-ul">
                    <li class="active-two-li">
                        <a href="<?php echo url('manager/index'); ?>">管理员列表
                            <!--   <span class="glyphicon glyphicon-menu-right right-icon"></span> -->
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo url('manager/add'); ?>">添加管理员
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="#">
                    <span class="glyphicon glyphicon-list-alt left-icon"></span>栏目
                    <span class="glyphicon glyphicon-menu-right right-icon"></span>
                </a>
                <ul class="two-ul">
                    <li>
                        <a href="<?php echo url('category/index'); ?>">栏目列表
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo url('category/add'); ?>">添加栏目
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo url('category/edit'); ?>">栏目编辑
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="#">
                    <span class="glyphicon glyphicon-cog left-icon"></span>系统
                    <span class="glyphicon glyphicon-menu-right right-icon"></span>
                </a>
                <ul class="two-ul">
                    <li>
                        <a href="admininfo.html">系统信息
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="adminlogin.html">
                    <span class="glyphicon glyphicon-log-out left-icon"></span>登出
                    <span class="glyphicon glyphicon-menu-right right-icon"></span>
                </a>
            </li>
        </ul>
    </div>
</nav>
<!--菜单列表结束-->
        <!--右侧主内容开始-->
        <section class="top-title">
            <div class="col-md-12 column">
                <ol class="breadcrumb">
                    <li><a href="index.html">控制面板</a></li>
                    <li class="active">添加管理员</li>
                </ol>
            </div>
        </section>
            <div class="rightbody">
                    <div class="myform-form">
                        <form action="add" method="post">
                            <p class="myform-line">
                                <label class="myform-left">管理员账号：</label>
                                <input class="myform-right" name="userName" required="required" type="text"
                                       placeholder="请输入管理员账号">
                            </p>
                            <p class="myform-line">
                                <label class="myform-left">管理员密码：</label>
                                <input class="myform-right" name="password" required="required" type="password"
                                       placeholder="请输入管理员密码">
                            </p>
                            <p class="myform-line">
                                <label class="myform-left">确认密码：</label>
                                <input class="myform-right" name="rePassword" required="required" type="password"
                                       placeholder="请确认密码">
                            </p>
                            <p class="myform-line">
                                <label class="myform-left"> </label>
                                <!--左边占宽-->
                                <input class="myform-right myform-btn" type="submit" value="添加">
                            </p>
                        </form>
                    </div>
            </div>
        <!--右侧主内容结束-->
    </div>
</div>
<script src="/static/admin/js/jquery.min.js"></script>
<script src="/static/admin/js/bootstrap.min.js"></script>
<script>
    $(function () {
        $('#ulNav>li').click(function () {
            $(this).toggleClass('active-liNav');
        })
    })
</script>
</body>

</html>