<?php
/**
 * Created by PhpStorm.
 * User:  pso318
 * Date: 2018/9/8
 * Time: 21:57
 */
return [
    'view_replace_str'  =>  [
        '__PUBLIC__'=>'/static/admin',

    ],
];